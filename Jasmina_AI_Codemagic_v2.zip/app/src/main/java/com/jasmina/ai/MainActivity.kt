package com.jasmina.ai
import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
class MainActivity: Activity(){
 override fun onCreate(b:Bundle?){super.onCreate(b)
  val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(32,32,32,32);setBackgroundColor(Color.rgb(9,9,20))}
  val title=TextView(this).apply{text="JASMINA";textSize=32f;setTextColor(Color.WHITE);gravity=Gravity.CENTER}
  val status=TextView(this).apply{text="3D virtual yordamchi";textSize=17f;setTextColor(Color.LTGRAY);gravity=Gravity.CENTER;setPadding(0,20,0,30)}
  val btn=Button(this).apply{text="Jasmina bilan suhbat";setOnClickListener{status.text="Salom! Men Jasminaman. Keyingi bosqichda AI, ovoz va 3D avatar ulanadi."}}
  root.addView(title);root.addView(status);root.addView(btn);setContentView(root)
 }
}
