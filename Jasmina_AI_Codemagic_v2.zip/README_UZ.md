# Jasmina AI
Bugungi kelishuv asosidagi Android loyiha.
- 3D virtual yordamchi
- O'zbek, rus, ingliz, turk
- mayin sho'x qiz ovozi
- anime elf avatar, Frieren estetikasi ilhomida
- ovozli/matnli suhbat
- Android funksiyalarini ruxsatlar/APIlar orqali boshqarish
- modul asosidagi self-upgrade, xavfli o'zgarishlarda foydalanuvchi tasdig'i
`codemagic.yaml` Codemagic uchun qo'shilgan.
